//
//  CAShapeLayerWithClipRender.h
//  SVGKit-iOS
//
//  Created by David Gileadi on 8/14/14.
//  Copyright (c) 2014 na. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface CAShapeLayerWithClipRender : CAShapeLayer

@end
