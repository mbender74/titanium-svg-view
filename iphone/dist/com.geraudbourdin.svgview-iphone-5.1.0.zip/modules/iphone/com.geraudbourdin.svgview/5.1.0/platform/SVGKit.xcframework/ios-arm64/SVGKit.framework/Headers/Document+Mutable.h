#import "Document.h"

@interface Document ()

@property(nonatomic,strong,readwrite) Element*          documentElement;

@end
