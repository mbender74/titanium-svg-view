//
//  SVGPathElement.h
//  SVGKit
//
//  Copyright Matt Rajca 2010-2011. All rights reserved.
//

#import "BaseClassForAllSVGBasicShapes.h"
#import "BaseClassForAllSVGBasicShapes_ForSubclasses.h"

@interface SVGPathElement : BaseClassForAllSVGBasicShapes { }

@end
